//
// Created by <Name> on <Date>.
//
#pragma once

#include "accounttree.h"
#include <fstream>
#include <queue>
#include <sstream>
#include <string>

using namespace std;

class Bank {
  public:
    Bank();
    ~Bank();

    void processTransactions(const string& fileName);
    void displayAllBankBalances();

  private:
    ifstream inFile;
    string str;
    queue<string> readQueue;
    AccountTree accounts;
    stringstream parseString;
};
