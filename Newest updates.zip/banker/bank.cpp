//
// Created by <Name> on <Date>.
//

#include "bank.h"

// empty

#include "account.h"
#include "bank.h"
#include <fstream>
#include <iostream>
#include <queue>
#include <sstream>

Bank::Bank() { AccountTree accounts; }

Bank::~Bank() = default;

void Bank::processTransactions(const string& fileName) {

    // open file and make sure it worked
    inFile.open(fileName);
    if (!inFile) {
        cout << "Unable to open file";
        exit(1); // terminate with error
    }

    // until the end of file is reached, read lines into a queue
    while (!inFile.eof()) {
        getline(inFile, str);
        readQueue.push(str);
    }
    inFile.close();

    // Loop through each line in queue
    while (readQueue.size() >= 1) {
        stringstream parseString;
        str = readQueue.front();
        readQueue.pop();
        parseString << str;
        string storage[4];
        int i = 0;

        // read and parse transaction
        while (parseString.good() && i < 4) {
            parseString >> storage[i];
            ++i;
        }

        Account* acctPtr = nullptr;
        Account* toPtr = nullptr;
        if (storage[0].front() == 'O') { // open account
            acctPtr = new Account(storage[2], storage[1], stoi(storage[3]));
            accounts.insert(acctPtr);
        } else if (storage[0].front() == 'D') { // deposit
            accounts.retrieve(stoi(storage[1]), acctPtr);
            acctPtr->deposit(stoi(storage[1]), stoi(storage[2]));
        } else if (storage[0].front() == 'W') { // withdraw
            accounts.retrieve(stoi(storage[1]), acctPtr);
            acctPtr->withdraw(stoi(storage[1]), stoi(storage[2]));
        } else if (storage[0].front() == 'T') { // transfer
            if (accounts.retrieve(stoi(storage[1]), acctPtr) &&
                accounts.retrieve(stoi(storage[3]), toPtr)) {
                accounts.transfer(stoi(storage[1]), stoi(storage[3]),
                                  stoi(storage[2]));
            }
        } else { // display history
            accounts.retrieve(stoi(storage[1]), acctPtr);
            acctPtr->displayHistory(stoi(storage[1]));
        }
    }
}

// displays all bank balances
void Bank::displayAllBankBalances() { accounts.display(); }
