//
// Created by <Name> on <Date>.
//

#include "bank.h"

// empty

Bank::Bank() = default;

Bank::~Bank() = default;

void Bank::processTransactions(const string& fileName) {}

void Bank::displayAllBankBalances() const {}